module.exports = require("@discourse/lint-configs/prettier");
